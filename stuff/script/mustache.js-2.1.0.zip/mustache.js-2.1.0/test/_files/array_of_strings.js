({
  array_of_strings: ['hello', 'world']
})
