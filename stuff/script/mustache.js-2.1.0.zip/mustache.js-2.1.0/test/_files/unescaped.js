({
  title: function () {
    return "Bear > Shark";
  }
})
